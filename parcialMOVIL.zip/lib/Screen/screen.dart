import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../Models/modelo.dart';

class SalonBelleza extends StatefulWidget {
  @override
  _SalonBellezaState createState() => _SalonBellezaState();
}

class _SalonBellezaState extends State<SalonBelleza> {
  late List<Modelo>
      welcomeList; // Lista para almacenar los datos recibidos de Modelo

  @override
  void initState() {
    super.initState();
    salon(); // Llama a la función para obtener los salones al iniciar
  }

  Future<void> salon() async {
    final response = await http
        .get(Uri.parse('https://www.datos.gov.co/resource/e27n-di57.json'));
    final List<dynamic> responseData = json.decode(response.body);

    setState(() {
      welcomeList = responseData
          .map((json) => Modelo.fromJson(json))
          .toList(); // Convierte los datos JSON a objetos Modelo
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Salones 🤍',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
        ),
        backgroundColor: Colors.pinkAccent,
      ),
      body: welcomeList == null
          ? Center(
              child:
                  CircularProgressIndicator()) // Muestra un indicador de carga si la lista está vacía
          : ListView.builder(
              itemCount: welcomeList.length,
              itemBuilder: (ctx, index) => GestureDetector(
                onTap: () {
                  _detallesDiaologo(welcomeList[
                      index]); // Muestra el diálogo de detalles al hacer clic en un elemento
                },
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.pink,
                        child: Icon(
                          Icons.storage,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              welcomeList[index].razonSocial,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "Nit: ${welcomeList[index].nitPropietario}",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.grey[600],
                              ),
                            ),
                            Text(
                              "Barrio: ${welcomeList[index].barrioComercial}",
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  void _detallesDiaologo(Modelo salon) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            salon.razonSocial,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                "Razon social: ${salon.razonSocial}",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                "Dirección de la matricula: ${salon.matricula}",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                "Dirección comercial: ${salon.direccionComercial}",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                "Ultimo año renovado: ${salon.ultimoAORenovado}",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context)
                    .pop(); // Cierra el diálogo al hacer clic en "Cerrar"
              },
              child: Text("Cerrar"),
            ),
          ],
        );
      },
    );
  }
}
