package com.example.parcial_maria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
