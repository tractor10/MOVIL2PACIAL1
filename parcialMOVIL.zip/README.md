# parcial_maria

A new Flutter project created with FlutLab - https://flutlab.io

## Getting Started

![Lista del consumo del API](<iPhone 12 Pro-1693451082889.jpeg>)

![Selección de cualquier campo](<iPhone 12 Pro-1693451703118.jpeg>) 

Instalar:
* dart pub add http